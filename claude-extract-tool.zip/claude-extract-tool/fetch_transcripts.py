"""
Fetch transcript from the latest video on the Claude YouTube channel.
Saves one transcript file per video with name and date posted.
"""

import os
import re
import subprocess
import json
from pathlib import Path
from youtube_transcript_api import YouTubeTranscriptApi

CHANNEL_URL = "https://www.youtube.com/@claude"
TRANSCRIPTS_DIR = Path(__file__).parent / "transcripts"
MAX_VIDEOS = 1  # Change this to fetch more videos


def sanitize_filename(name: str) -> str:
    """Remove characters that are invalid in filenames."""
    return re.sub(r'[\\/*?:"<>|]', "", name).strip()


def get_latest_videos(channel_url: str, max_videos: int = 1) -> list[dict]:
    """Use yt-dlp to get metadata for the latest videos from a channel."""
    cmd = [
        "yt-dlp",
        "--flat-playlist",
        "--dump-json",
        "--playlist-end", str(max_videos),
        f"{channel_url}/videos",
    ]

    result = subprocess.run(cmd, capture_output=True, text=True, check=True)

    videos = []
    for line in result.stdout.strip().split("\n"):
        if not line:
            continue
        data = json.loads(line)
        videos.append({
            "id": data.get("id"),
            "title": data.get("title", "Unknown Title"),
            "upload_date": data.get("upload_date", "Unknown"),
        })

    return videos


def format_upload_date(date_str: str) -> str:
    """Convert YYYYMMDD to YYYY-MM-DD."""
    if len(date_str) == 8 and date_str.isdigit():
        return f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:]}"
    return date_str


def fetch_transcript(video_id: str) -> str | None:
    """Fetch transcript text for a given video ID."""
    try:
        transcript_list = YouTubeTranscriptApi.get_transcript(video_id)
        lines = [entry["text"] for entry in transcript_list]
        return "\n".join(lines)
    except Exception as e:
        print(f"  Could not fetch transcript for {video_id}: {e}")
        return None


def main():
    TRANSCRIPTS_DIR.mkdir(exist_ok=True)

    print(f"Fetching latest {MAX_VIDEOS} video(s) from {CHANNEL_URL}...")
    videos = get_latest_videos(CHANNEL_URL, MAX_VIDEOS)

    if not videos:
        print("No videos found.")
        return []

    saved_files = []

    for video in videos:
        title = video["title"]
        date = format_upload_date(video["upload_date"])
        video_id = video["id"]

        print(f"  Processing: {title} ({date})")

        transcript_text = fetch_transcript(video_id)
        if transcript_text is None:
            continue

        safe_title = sanitize_filename(title)
        filename = f"{safe_title}_{date}.txt"
        filepath = TRANSCRIPTS_DIR / filename

        header = (
            f"Video: {title}\n"
            f"Date Posted: {date}\n"
            f"URL: https://www.youtube.com/watch?v={video_id}\n"
            f"{'=' * 60}\n\n"
        )

        filepath.write_text(header + transcript_text, encoding="utf-8")
        print(f"  Saved: {filepath}")
        saved_files.append(str(filepath))

    print(f"\nDone. {len(saved_files)} transcript(s) saved to {TRANSCRIPTS_DIR}/")
    return saved_files


if __name__ == "__main__":
    main()
