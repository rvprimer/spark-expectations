"""
Read transcripts and keywords.txt, then use Google Gemini API to find
and extract context around each keyword/phrase in the transcript.
"""

import os
import json
from pathlib import Path
from datetime import datetime

from google import genai

TRANSCRIPTS_DIR = Path(__file__).parent / "transcripts"
RESULTS_DIR = Path(__file__).parent / "results"
KEYWORDS_FILE = Path(__file__).parent / "keywords.txt"
MODEL = "gemini-2.0-flash"


def load_keywords() -> list[str]:
    """Load keywords from keywords.txt (one per line, skip blanks)."""
    if not KEYWORDS_FILE.exists():
        raise FileNotFoundError(f"Keywords file not found: {KEYWORDS_FILE}")

    keywords = []
    for line in KEYWORDS_FILE.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            keywords.append(stripped)

    if not keywords:
        raise ValueError("keywords.txt is empty. Add one keyword per line.")

    return keywords


def load_transcripts() -> list[dict]:
    """Load all transcript files from the transcripts directory."""
    transcripts = []
    for filepath in sorted(TRANSCRIPTS_DIR.glob("*.txt")):
        content = filepath.read_text(encoding="utf-8")
        transcripts.append({
            "filename": filepath.name,
            "content": content,
        })
    return transcripts


def build_prompt(transcript_content: str, keywords: list[str]) -> str:
    """Build the Gemini prompt for keyword extraction."""
    keywords_formatted = "\n".join(f"- {kw}" for kw in keywords)

    return f"""Analyze the following video transcript and find all mentions or discussions 
related to each keyword/phrase listed below. For each keyword found:

1. Quote the relevant sentence or passage (keep it concise, 1-3 sentences max)
2. Note approximately where in the transcript it appears (beginning/middle/end)
3. Provide brief context about what was being discussed

If a keyword is NOT mentioned or discussed in the transcript, explicitly state "Not found."

KEYWORDS TO SEARCH FOR:
{keywords_formatted}

TRANSCRIPT:
{transcript_content}

Respond in JSON format with this structure:
{{
  "results": [
    {{
      "keyword": "the keyword",
      "found": true/false,
      "mentions": [
        {{
          "quote": "relevant quote from transcript",
          "position": "beginning/middle/end",
          "context": "brief explanation of what was being discussed"
        }}
      ]
    }}
  ],
  "summary": "2-3 sentence overview of the video's main topics"
}}"""


def extract_keywords_from_transcript(
    client: genai.Client,
    transcript: dict,
    keywords: list[str],
) -> dict:
    """Send a transcript + keywords to Gemini and get extraction results."""
    prompt = build_prompt(transcript["content"], keywords)

    response = client.models.generate_content(
        model=MODEL,
        contents=prompt,
    )

    response_text = response.text.strip()
    if response_text.startswith("```"):
        response_text = response_text.split("\n", 1)[1]
        if response_text.endswith("```"):
            response_text = response_text[:-3]

    try:
        parsed = json.loads(response_text)
    except json.JSONDecodeError:
        parsed = {"raw_response": response_text, "parse_error": True}

    return {
        "source_file": transcript["filename"],
        "extraction": parsed,
    }


def main():
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        print("ERROR: Set the GEMINI_API_KEY environment variable.")
        print("  Get a free key at: https://aistudio.google.com/apikey")
        print("  Then run: export GEMINI_API_KEY='your-key-here'")
        return []

    RESULTS_DIR.mkdir(exist_ok=True)

    keywords = load_keywords()
    print(f"Loaded {len(keywords)} keyword(s) from {KEYWORDS_FILE.name}")

    transcripts = load_transcripts()
    if not transcripts:
        print(f"No transcripts found in {TRANSCRIPTS_DIR}/. Run fetch_transcripts.py first.")
        return []

    print(f"Found {len(transcripts)} transcript(s) to analyze.")

    client = genai.Client(api_key=api_key)
    saved_files = []

    for transcript in transcripts:
        print(f"  Analyzing: {transcript['filename']}...")

        result = extract_keywords_from_transcript(client, transcript, keywords)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        source_stem = Path(transcript["filename"]).stem
        output_filename = f"{source_stem}_keywords_{timestamp}.json"
        output_path = RESULTS_DIR / output_filename

        output_path.write_text(
            json.dumps(result, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        print(f"  Saved: {output_path}")
        saved_files.append(str(output_path))

    print(f"\nDone. {len(saved_files)} result(s) saved to {RESULTS_DIR}/")
    return saved_files


if __name__ == "__main__":
    main()
