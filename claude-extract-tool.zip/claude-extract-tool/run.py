"""
Orchestrator: fetch transcripts then extract keywords.
Run standalone or as a scheduled daemon.

Usage:
    python run.py              # Run once
    python run.py --daemon     # Run on a schedule (default: daily at 09:00)
"""

import argparse
import sys

import fetch_transcripts
import extract_keywords


def run_pipeline():
    """Execute the full pipeline: fetch transcripts, then extract keywords."""
    print("=" * 60)
    print("STEP 1: Fetching transcripts from Claude YouTube channel")
    print("=" * 60)
    saved_transcripts = fetch_transcripts.main()

    if not saved_transcripts:
        print("\nNo new transcripts fetched. Skipping keyword extraction.")
        return

    print()
    print("=" * 60)
    print("STEP 2: Extracting keywords via Gemini API")
    print("=" * 60)
    extract_keywords.main()

    print()
    print("=" * 60)
    print("Pipeline complete.")
    print("=" * 60)


def run_daemon(time_of_day: str = "09:00"):
    """Run the pipeline on a daily schedule."""
    try:
        import schedule
        import time
    except ImportError:
        print("ERROR: 'schedule' package required for daemon mode.")
        print("  Install it: pip install schedule")
        sys.exit(1)

    print(f"Daemon mode: will run daily at {time_of_day}")
    print("Press Ctrl+C to stop.\n")

    schedule.every().day.at(time_of_day).do(run_pipeline)

    # Run once immediately on start
    run_pipeline()

    while True:
        schedule.run_pending()
        time.sleep(60)


def main():
    parser = argparse.ArgumentParser(
        description="Fetch Claude YouTube transcripts and extract keywords."
    )
    parser.add_argument(
        "--daemon",
        action="store_true",
        help="Run on a recurring daily schedule instead of once.",
    )
    parser.add_argument(
        "--time",
        default="09:00",
        help="Time of day to run in daemon mode (HH:MM, default: 09:00).",
    )
    args = parser.parse_args()

    if args.daemon:
        run_daemon(args.time)
    else:
        run_pipeline()


if __name__ == "__main__":
    main()
