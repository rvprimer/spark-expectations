# Claude YouTube Transcript Keyword Extractor

Fetches transcripts from the [Claude YouTube channel](https://www.youtube.com/@claude), then uses Google Gemini AI to find and extract mentions of specific keywords you define.

## Quick Start

### 1. Install dependencies

```bash
cd ~/Desktop/claude-extract-tool
python3 -m venv venv

# macOS / Linux
source venv/bin/activate

# Windows
venv\Scripts\activate

pip install -r requirements.txt
```

You also need `yt-dlp` available on your PATH. If `pip install yt-dlp` doesn't put it on your path:

```bash
# macOS (Homebrew)
brew install yt-dlp

# Windows (winget)
winget install yt-dlp
```

### 2. Get a Gemini API key (free)

1. Go to https://aistudio.google.com/apikey
2. Create a key
3. Set it as an environment variable:

```bash
# macOS / Linux
export GEMINI_API_KEY="your-key-here"

# Windows (PowerShell)
$env:GEMINI_API_KEY = "your-key-here"

# Windows (CMD)
set GEMINI_API_KEY=your-key-here
```

### 3. Edit keywords

Open `keywords.txt` and put one keyword or phrase per line:

```
Claude 4
MCP
pricing
```

Lines starting with `#` are ignored.

### 4. Run

```bash
python run.py
```

This will:
1. Fetch the transcript of the latest video from @claude
2. Save it to `transcripts/`
3. Send it to Gemini with your keywords
4. Save structured results to `results/`

## Running on a Schedule

### Option A: Built-in daemon mode (cross-platform)

```bash
python run.py --daemon --time 09:00
```

Runs once immediately, then repeats daily at 09:00. Keep the terminal open or run in background.

### Option B: macOS cron job

```bash
crontab -e
```

Add this line (runs daily at 9 AM):

```
0 9 * * * cd /Users/YOURNAME/Desktop/claude-extract-tool && /Users/YOURNAME/Desktop/claude-extract-tool/venv/bin/python run.py >> /tmp/claude-extract.log 2>&1
```

### Option C: Windows Task Scheduler

1. Open Task Scheduler
2. Create Basic Task
3. Set trigger (e.g., Daily at 9:00 AM)
4. Action: Start a program
   - Program: `C:\Users\YOURNAME\Desktop\claude-extract-tool\venv\Scripts\python.exe`
   - Arguments: `run.py`
   - Start in: `C:\Users\YOURNAME\Desktop\claude-extract-tool`

### Option D: macOS launchd (survives reboots)

Create `~/Library/LaunchAgents/com.claude-extract.plist`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.claude-extract</string>
    <key>ProgramArguments</key>
    <array>
        <string>/Users/YOURNAME/Desktop/claude-extract-tool/venv/bin/python</string>
        <string>/Users/YOURNAME/Desktop/claude-extract-tool/run.py</string>
    </array>
    <key>StartCalendarInterval</key>
    <dict>
        <key>Hour</key>
        <integer>9</integer>
        <key>Minute</key>
        <integer>0</integer>
    </dict>
    <key>WorkingDirectory</key>
    <string>/Users/YOURNAME/Desktop/claude-extract-tool</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>GEMINI_API_KEY</key>
        <string>your-key-here</string>
    </dict>
    <key>StandardOutPath</key>
    <string>/tmp/claude-extract.log</string>
    <key>StandardErrorPath</key>
    <string>/tmp/claude-extract-error.log</string>
</dict>
</plist>
```

Load it:

```bash
launchctl load ~/Library/LaunchAgents/com.claude-extract.plist
```

## Output

- `transcripts/` - One `.txt` file per video with title, date, and full transcript
- `results/` - One `.json` file per analysis with keyword matches and context

## Configuration

| Setting | Location | Default |
|---------|----------|---------|
| Keywords to search | `keywords.txt` | Example keywords included |
| Number of videos | `fetch_transcripts.py` → `MAX_VIDEOS` | 1 |
| Gemini model | `extract_keywords.py` → `MODEL` | gemini-2.0-flash |
| Schedule time | `--time` flag | 09:00 |
